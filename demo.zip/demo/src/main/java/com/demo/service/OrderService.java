package com.demo.service;

import com.demo.model.Orders;

public interface OrderService {
	public Orders saveOrder(Orders order);
}
